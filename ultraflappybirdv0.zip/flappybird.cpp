#include <SDL2/SDL.h>
#include <iostream>
#include <vector>
#include <chrono>

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int PIPE_WIDTH = 100;
const int PIPE_SPEED = 2;
const int FPS = 60;
const int FRAME_DELAY = 1000 / FPS;  // Calculate the frame delay in milliseconds

struct Pipe {
    int x, y, gapHeight;
};

class Game {
public:
    Game();
    ~Game();
    void run();

private:
    SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    SDL_Event event;
    bool isRunning;
    int score;
    std::vector<Pipe> pipes;
    int birdY;
    int birdVelocity;

    void initSDL();
    void handleEvents();
    void update();
    void render();
    void cleanUp();
    void addPipe();
};

Game::Game() : isRunning(false), score(0), birdY(SCREEN_HEIGHT / 2), birdVelocity(0) {}

Game::~Game() {
    cleanUp();
}

void Game::initSDL() {
    SDL_Init(SDL_INIT_VIDEO);
    window = SDL_CreateWindow("Flappy Bird Clone", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, 0);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
}

void Game::handleEvents() {
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            isRunning = false;
        }
        if (event.type == SDL_KEYDOWN) {
            if (event.key.keysym.sym == SDLK_SPACE) {
                birdVelocity = -10; // Jump
            }
        }
    }
}

void Game::update() {
    birdY += birdVelocity;
    birdVelocity += 1; // Gravity effect

    for (auto& pipe : pipes) {
        pipe.x -= PIPE_SPEED;
    }

    if (pipes.empty() || pipes.back().x < SCREEN_WIDTH - 200) {
        addPipe();
    }
}

void Game::render() {
    SDL_SetRenderDrawColor(renderer, 135, 206, 235, 255); // Sky blue background
    SDL_RenderClear(renderer);

    // Render bird
    SDL_Rect birdRect = {SCREEN_WIDTH / 4, birdY, 30, 30};
    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255); // Yellow bird
    SDL_RenderFillRect(renderer, &birdRect);

    // Render pipes
    for (const auto& pipe : pipes) {
        SDL_SetRenderDrawColor(renderer, 0, 128, 0, 255); // Green pipes
        SDL_Rect topPipe = {pipe.x, 0, PIPE_WIDTH, pipe.y};
        SDL_Rect bottomPipe = {pipe.x, pipe.y + pipe.gapHeight, PIPE_WIDTH, SCREEN_HEIGHT - pipe.y - pipe.gapHeight};
        SDL_RenderFillRect(renderer, &topPipe);
        SDL_RenderFillRect(renderer, &bottomPipe);
    }

    SDL_RenderPresent(renderer);
}

void Game::addPipe() {
    int gapHeight = 150; // Gap between the top and bottom pipe
    int gapPosition = rand() % (SCREEN_HEIGHT - gapHeight - 200) + 100; // Random gap position
    pipes.push_back({SCREEN_WIDTH, gapPosition, gapHeight});
}

void Game::cleanUp() {
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}

void Game::run() {
    initSDL();
    isRunning = true;
    auto lastTime = std::chrono::system_clock::now();

    while (isRunning) {
        handleEvents();
        update();
        render();

        // Frame rate control
        auto currentTime = std::chrono::system_clock::now();
        auto frameTime = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastTime).count();
        if (frameTime < FRAME_DELAY) {
            SDL_Delay(FRAME_DELAY - frameTime);
        }
        lastTime = currentTime;
    }
}

int main() {
    Game game;
    game.run();
    return 0;
}
